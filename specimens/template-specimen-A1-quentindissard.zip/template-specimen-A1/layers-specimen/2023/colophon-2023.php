 <p id="footer">
      Specimen typographique mis en page sur Paged.js lors du workshop HTML2print avec Benjamin Dumond, DN2 mars 2023, Boulogne Billancourt
 </p>