    <div id="boite-texte3">
      <p class="infos">Typographies réalisées lors d'un workshop<br>initiée par Morgane Pierson<br> en [&emsp;2023&emsp;]
        <br><br><br><br><br><br><br><br>

        Sophie Aube<br>
        Amandine Courbot<br>
        Aurélien Maufroid<br>
        Ivo Querniard<br>
        Sarah Garraud<br>
        Clara Saffre<br>
        Maïlys Larmitou<br>
        Marion Vilette<br>
        Zoé Leroux<br>
        Antoine Liberman<br>
        Yasmine Tissaoui<br>
        Marine Drouin<br>
        Candice Terle<br><br><br><br><br>
        
        Les typographies ont été conçues<br>
        en s'inspirant de leur écriture manuscrite<br><br><br><br><br><br><br><br><br>

        Affiche - Impression : 594 x 841mm<br><br>
      </p>
    </div>