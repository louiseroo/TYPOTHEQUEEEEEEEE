      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="aube">aube</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="bazar">bazaram</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="boniot">BONIOT</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="ducere">DUCERE</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">30 glyphs</p>
        <p id="frimousse">frimousse</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="glouglou">glouglou</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="kiffance">KIFFANCE</p>
        <p class="point-typo">165 pt</p> 
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="leana">leana</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="lutine">lutine</p>
        <p class="point-typo">165 pt</p> 
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="maingauche">MAIN GAUCHE</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="mina">mina</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="vitejuin">vite juin</p>
        <p class="point-typo">165 pt</p>
      </article>
            <article>
        <p class="glyphs">26 glyphs</p>
        <p id="way">way</p>
        <p class="point-typo">165 pt</p>
      </article>