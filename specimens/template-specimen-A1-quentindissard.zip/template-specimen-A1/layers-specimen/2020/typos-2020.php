      <article>
        <p class="glyphs">30 glyphs</p>
        <p id="water">WATER</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">54 glyphs</p>
        <p id="poison">Poison</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="rock">ROCK</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">44 glyphs</p>
        <p id="psychic">PSYCHIC</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">36 glyphs</p>
        <p id="ice">ICE</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">62 glyphs</p>
        <p id="bug">bug</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="dragon">DRAGON</p>
        <p class="point-typo">165 pt</p> 
      </article>
      <article>
        <p class="glyphs">33 glyphs</p>
        <p id="electric">ELECTRIC</p>
        <p class="point-typo">165 pt</p> 
      </article>
      <article>
        <p class="glyphs">62 glyphs</p>
        <p id="fighting">fighting</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="fire">FIRE</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">36 glyphs</p>
        <p id="flying">FLYING</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">36 glyphs</p>
        <p id="ghost">GHOST</p>
        <p class="point-typo">165 pt</p>
      </article>