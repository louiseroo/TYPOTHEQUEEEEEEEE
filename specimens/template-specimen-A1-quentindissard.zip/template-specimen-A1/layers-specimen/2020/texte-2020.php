    <div id="boite-texte">
      <p class="infos">Typographies dessinées lors d'un workshop<br>initiée par Lucas Descroix<br> en [&emsp;2020&emsp;]<br><br><br>

        Sarah Marouzé<br>
        Enora Pichavant<br>
        Laura François<br>
        Martin Gouriou<br>
        Léo Gobin<br>
        Elodie Perez<br>
        Jessy Moreira<br>
        Emma Grosu<br>
        Julia Rodriguez<br>
        Julia Koussa<br>
        Tonya Palcy<br>
        Erwan Batnini<br>
        Julia Koussa<br><br><br>
        
        Les typographies ont été conçues<br>
        en s'inspirant des types de pokémon<br><br><br><br><br>

        [&emsp;acier&emsp;]<br>
        [&emsp;combat&emsp;]<br>
        [&emsp;dragon&emsp;]<br>
        [&emsp;eau&emsp;]<br>
        [&emsp;electrique&emsp;]<br>
        [&emsp;fée&emsp;]<br>
        [&emsp;feu&emsp;]<br>
        [&emsp;glace&emsp;]<br>
        [&emsp;insecte&emsp;]<br>
        [&emsp;normal&emsp;]<br>
        [&emsp;plante&emsp;]<br>
        [&emsp;poison&emsp;]<br>
        [&emsp;psy&emsp;]<br>
        [&emsp;roche&emsp;]<br>
        [&emsp;sol&emsp;]<br>
        [&emsp;spectre&emsp;]<br>
        [&emsp;ténèbres&emsp;]<br>
        [&emsp;vol&emsp;]<br>
        [&emsp;inconnu&emsp;]<br>
        [&emsp;obscur&emsp;]<br><br><br><br><br>  

        Le type [&emsp;Eau&emsp;]<br> est celui qui recense le plus de Pokémon, 
        et ses représentants décrivent tous <br> les doubles types possibles.<br> 
        Il est souvent associé aux<br> types Roche et Sol.<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

        Le type [&emsp;Poison&emsp;]<br> seul Glace/Poison ne compte
        aucun représentant.<br> Il est souvent associé aux<br>
        types Plante et Insecte.<br><br><br><br><br>

        Le type [&emsp;Roche&emsp;]<br> Les types Eau et Sol sont ceux avec lesquels
        le type Roche s'associe<br> le plus souvent.<br> 
        Seule la combinaison<br> Normal/Roche <br>manque à<br> l'appel.<br><br><br><br><br><br><br><br><br><br>

        Le type [&emsp;Feu&emsp;]<br> Parmi les doubles types<br> contenant Feu,<br> 
        seul Fée/Feu<br> ne compte aucun<br> représentant.<br><br><br><br><br><br><br>

        Affiche - Impression : 594 x 841mm<br><br>
      </p>
    </div>