<div id="boite-texte2">
      <p class="infos">Typographies conçus lors d'un workshop<br>initiée par Rémi Forte<br> en [&emsp;2022&emsp;]
        <br><br><br><br><br><br><br><br><br>

        Laure Azizi<br>
        Léa Toluzzo<br>
        Louanne Fournier<br>
        Pierre Roussel<br>
        Le&iuml;la Courset<br>
        Josselin Romé<br><br><br><br><br><br><br><br><br><br><br>

        Les typographies ont été conçues<br>
        en s'inspirant d'un système de grille'<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> 

        Affiche - Impression : 594 x 841mm<br><br>
      </p>
</div>