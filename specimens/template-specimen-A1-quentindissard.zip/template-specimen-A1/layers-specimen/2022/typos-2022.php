      <article>
        <p class="glyphs">7 glyphs</p>
        <p id="brutal">brutal</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p id="glyphs-eartheater">26 glyphs</p>
        <p id="eartheater">Eartheater Cross</p>
        <p id="point-typo-eartheater">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="frankgrayishiding">Frankgrayishiding</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="tricurve">Tricurve</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">4 glyphs</p>
        <p id="fuite">HELP</p>
        <p class="point-typo">165 pt</p>
      </article>
      <article>
        <p class="glyphs">26 glyphs</p>
        <p id="lablab">Lablab</p>
        <p class="point-typo">165 pt</p>
      </article>