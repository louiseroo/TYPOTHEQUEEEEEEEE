<div id="header">
      <p id="hight-cap">a</p>
        <p id="middle-cap">
          there was also a strangely soothing cosmic beauty in the hypnotic landscape where we climbed and dove fabulously.
        </p>
        <p id="point-typo3">20pt</p>
</div>

      <p id="point-typo">140pt</p>

    <div id="abcde">
      <p id="point-typo1">140pt</p>
        <p id="abcde-cap">
          abcde
        </p>
    </div>

    <div id="bas">
      <p id="gauche-cap">
        time had gone astray in the labyrinths left behind, and spread around us only the blooming waves of the fairy tale and the charm found in centuries gone. Venerable groves, fresh meadows lined with autumn flowers with bright colors, and from far and wide, small brown farms nestled among huge trees at the foot of vertical woodpeckers covered with fragrant rosehips and meadow grass. The sun itself took a prodigious shine, as if the whole country was bathed in an atmosphere or exhalation quite exceptional. I had not yet seen anything like it, except in the magical perspectives that sometimes form the background of the primitive Italians.
      </p><br>

        <p id="point-typo2-cap">6pt</p>

      <p id="droit-cap">
        there was also a strangely soothing cosmic beauty in the hypnotic landscape where we climbed and dove fabulously. Time had gone astray in the labyrinths left behind, and spread around us only the blooming waves of the fairy tale and the charm found in centuries gone. Venerable groves, fresh meadows lined with autumn flowers with bright colors, and from far and wide, small brown farms nestled among huge trees at the foot of vertical woodpeckers covered with fragrant rosehips and meadow grass.
      </p>
      <p id="point-typo4-cap">12pt</p>
    </div>

    <div id="aba">
      <p id="aba-cap">
        abcdef
      </p>
      <p id="point-typo5-cap">80pt</p>
    </div>
